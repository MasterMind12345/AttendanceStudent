<?php
require_once '../includes/config.php';

require_once '../includes/functions.php';



if (!isset($_GET['id'])) {
    redirect('dashboard.php');
}

$seance_id = $_GET['id'];
$seance = getSeanceById($seance_id);
$presences = getPresencesBySeance($seance_id);

if (!$seance) {
    redirect('dashboard.php');
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Présences - Gestion des présences</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Gestion des présences</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Tableau de bord</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="create_seance.php">Créer une séance</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Liste des présences</h2>
            <div>
                <a href="seance_detail.php?id=<?= $seance_id ?>" class="btn btn-outline-secondary me-2">
                    <i class="bi bi-arrow-left"></i> Retour
                </a>
                <a href="export_presence.php?id=<?= $seance_id ?>" class="btn btn-success">
                    <i class="bi bi-file-excel"></i> Exporter
                </a>
            </div>
        </div>
        
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><?= htmlspecialchars($seance['cours_nom']) ?> - <?= date('d/m/Y H:i', strtotime($seance['date_heure'])) ?></h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($presences)): ?>
                                <tr>
                                    <td colspan="5" class="text-center">Aucune présence enregistrée</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($presences as $index => $presence): ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td><?= htmlspecialchars($presence['nom']) ?></td>
                                        <td><?= htmlspecialchars($presence['prénom']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $presence['statut'] === 'présent' ? 'success' : ($presence['statut'] === 'justifié' ? 'warning' : 'danger') ?>">
                                                <?= ucfirst($presence['statut']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#bonusModal<?= $presence['id'] ?>">
                                                <i class="bi bi-plus-circle"></i> Bonus
                                            </button>
                                        </td>
                                    </tr>
                                    
                               
                                    <div class="modal fade" id="bonusModal<?= $presence['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Ajouter un bonus</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="POST" action="add_bonus.php">
                                                        <input type="hidden" name="presence_id" value="<?= $presence['id'] ?>">
                                                        <div class="mb-3">
                                                            <label for="points" class="form-label">Points bonus</label>
                                                            <input type="number" class="form-control" id="points" name="points" min="1" max="10" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="comment" class="form-label">Commentaire</label>
                                                            <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
                                                        </div>
                                                        <div class="d-grid gap-2">
                                                            <button type="submit" class="btn btn-primary">Ajouter</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>