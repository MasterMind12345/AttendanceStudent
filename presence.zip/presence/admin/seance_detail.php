<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';


error_reporting(E_ALL);
ini_set('display_errors', 1);



if (!isset($_GET['id'])) {
    redirect('dashboard.php');
}

$seance_id = $_GET['id'];
$seance = getSeanceById($seance_id);

if (!$seance) {
    redirect('dashboard.php');
}



$qr_data = urlencode("PRESENCE_IUT:".$seance_id.":".md5($seance_id.SECRET_KEY));
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de la séance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <style>
        #qrcode {
            width: 200px;
            height: 200px;
            margin: 0 auto;
            padding: 10px;
            background: white;
        }
        #qrcode img {
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Gestion des présences</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Tableau de bord</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="create_seance.php">Créer une séance</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-8">
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Détails de la séance</h4>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($seance['cours_nom']) ?></h5>
                        <p class="card-text"><strong>Date et heure:</strong> <?= date('d/m/Y H:i', strtotime($seance['date_heure'])) ?></p>
                        <p class="card-text"><strong>Sujet:</strong> <?= htmlspecialchars($seance['sujet']) ?></p>
                    </div>
                </div>
                
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Liste des présences</h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3">
                            <a href="view_presence.php?id=<?= $seance_id ?>" class="btn btn-outline-primary">
                                <i class="bi bi-list-check"></i> Voir les présences
                            </a>
                            <a href="export_presence.php?id=<?= $seance_id ?>" class="btn btn-success">
                                <i class="bi bi-file-excel"></i> Exporter en Excel
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">QR Code de présence</h4>
                    </div>
                    <div class="card-body text-center">
                        <div id="qrcode"></div>
                        <p class="text-muted mt-3">Scannez ce QR code pour marquer votre présence</p>
                        <button onclick="downloadQR()" class="btn btn-outline-primary">
                            <i class="bi bi-download"></i> Télécharger
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

  
<script>
  
    const qrData = "<?= "PRESENCE_IUT:".$seance_id.":".md5($seance_id.SECRET_KEY) ?>";
    const fullUrl = window.location.origin + '/verify_qr.php?data=' + encodeURIComponent(qrData);
    
    
    new QRCode(document.getElementById("qrcode"), {
        text: fullUrl, 
        width: 200,
        height: 200,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });


    function downloadQR() {
        const canvas = document.querySelector("#qrcode canvas");
        const link = document.createElement("a");
        link.download = "presence_<?= $seance_id ?>.png";
        link.href = canvas.toDataURL("image/png");
        link.click();
    }
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>