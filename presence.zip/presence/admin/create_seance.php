<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';



$error = '';
$success = '';


$cours = [];
try {
    $stmt = $db->query("SELECT * FROM cours");
    $cours = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Erreur lors de la récupération des cours: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cours_id = $_POST['cours_id'];
    $date_heure = $_POST['date_heure'];
    $sujet = trim($_POST['sujet']);
    
    if (empty($cours_id)){
        $error = "Veuillez sélectionner un cours";
    } elseif (empty($date_heure)) {
        $error = "Veuillez entrer une date et heure";
    } elseif (empty($sujet)) {
        $error = "Veuillez entrer un sujet";
    } else {
        if (createSeance($cours_id, $date_heure, $sujet)) {
            $success = "Séance créée avec succès";
            $_POST = []; 
        } else {
            $error = "Erreur lors de la création de la séance";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer une séance - Gestion des présences</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Gestion des présences</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Tableau de bord</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="create_seance.php">Créer une séance</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Créer une nouvelle séance</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="cours_id" class="form-label">Cours</label>
                                <select class="form-select" id="cours_id" name="cours_id" required>
                                    <option value="">Sélectionner un cours</option>
                                    <?php foreach ($cours as $c): ?>
                                        <option value="<?= $c['id'] ?>" <?= isset($_POST['cours_id']) && $_POST['cours_id'] == $c['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($c['nom']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="date_heure" class="form-label">Date et heure</label>
                                <input type="datetime-local" class="form-control" id="date_heure" name="date_heure" 
                                       value="<?= isset($_POST['date_heure']) ? htmlspecialchars($_POST['date_heure']) : '' ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="sujet" class="form-label">Sujet</label>
                                <textarea class="form-control" id="sujet" name="sujet" rows="3" required><?= isset($_POST['sujet']) ? htmlspecialchars($_POST['sujet']) : '' ?></textarea>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Créer la séance</button>
                                <a href="dashboard.php" class="btn btn-outline-secondary">Annuler</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>