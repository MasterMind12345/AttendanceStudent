<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';


$seances = getSeances();
$totalSeances = count($seances);
$totalEtudiants = $db->query("SELECT COUNT(*) FROM utilisateurs WHERE rôle = 'étudiant'")->fetchColumn();
$totalEnseignants = $db->query("SELECT COUNT(*) FROM utilisateurs WHERE rôle = 'enseignant'")->fetchColumn();


$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Admin - Gestion des Présences</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        .card-stat {
            transition: transform 0.3s;
            border-left: 5px solid;
        }
        .card-stat:hover {
            transform: translateY(-5px);
        }
        .card-stat.seances {
            border-left-color: #4e73df;
        }
        .card-stat.etudiants {
            border-left-color: #1cc88a;
        }
        .card-stat.enseignants {
            border-left-color: #f6c23e;
        }
        .seance-card {
            transition: all 0.3s;
        }
        .seance-card:hover {
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .navbar-brand img {
            height: 40px;
        }
        .sidebar {
            background: linear-gradient(180deg, #4e73df 0%, #224abe 100%);
            min-height: calc(100vh - 56px);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 1rem;
            font-weight: 600;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-link i {
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>
  
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="../assets/img/logo.png" alt="Logo" class="me-2">
                <span>Gestion des Présences</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?= htmlspecialchars($_SESSION['prenom'] . ' ' . $_SESSION['nom']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i>Profil</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Déconnexion</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
        
            <div class="col-lg-2 d-none d-lg-block sidebar p-0">
                <div class="pt-3">
                    <div class="text-center text-white mb-4">
                        <h5>Menu Administrateur</h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">
                                <i class="bi bi-speedometer2"></i> Tableau de bord
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="create_seance.php">
                                <i class="bi bi-calendar-plus"></i> Créer séance
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="gestion_utilisateurs.php">
                                <i class="bi bi-people"></i> Gestion utilisateurs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="gestion_cours.php">
                                <i class="bi bi-book"></i> Gestion cours
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <i class="bi bi-box-arrow-right"></i> Déconnexion
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

      
            <div class="col-lg-10 px-4 py-4">
      
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <h1 class="h3 mb-4 text-gray-800">Tableau de Bord Administrateur</h1>

           
                <div class="row mb-4">
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card border-0 shadow h-100 py-2 card-stat seances">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Séances programmées</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalSeances ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-calendar-event fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card border-0 shadow h-100 py-2 card-stat etudiants">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Étudiants</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalEtudiants ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-people fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card border-0 shadow h-100 py-2 card-stat enseignants">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Enseignants</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalEnseignants ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="bi bi-person-badge fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">Dernières séances programmées</h6>
                        <a href="create_seance.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-plus-circle"></i> Nouvelle séance
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($seances)): ?>
                            <div class="alert alert-info">Aucune séance programmée pour le moment</div>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach ($seances as $seance): ?>
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card seance-card h-100">
                                            <div class="card-header bg-light">
                                                <h5 class="card-title mb-0"><?= htmlspecialchars($seance['cours_nom']) ?></h5>
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text">
                                                    <i class="bi bi-calendar me-2"></i>
                                                    <?= date('d/m/Y H:i', strtotime($seance['date_heure'])) ?>
                                                </p>
                                                <p class="card-text text-muted">
                                                    <?= htmlspecialchars($seance['sujet']) ?>
                                                </p>
                                            </div>
                                            <div class="card-footer bg-transparent">
                                                <a href="seance_detail.php?id=<?= $seance['id'] ?>" class="btn btn-sm btn-outline-primary me-2">
                                                    <i class="bi bi-eye"></i> Détails
                                                </a>
                                                <a href="view_presence.php?id=<?= $seance['id'] ?>" class="btn btn-sm btn-outline-success">
                                                    <i class="bi bi-list-check"></i> Présences
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });
    </script>
</body>
</html>