<?php

$is_export = strpos($_SERVER['REQUEST_URI'], 'export_presence.php') !== false;

if ($is_export) {
    require_once '../includes/config.php';
    require_once '../includes/auth.php';
    require_once '../includes/functions.php';
}
if (!isset($_GET['id'])) {
    die("ID de séance manquant");
}

$seance_id = (int)$_GET['id'];
$seance = getSeanceById($seance_id);
$presences = getPresencesBySeance($seance_id);

if (!$seance) {
    die("Séance introuvable");
}


$filename = "presences_" . htmlspecialchars($seance['cours_nom']) . "_" . date('Y-m-d') . ".xlsx";


header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Cache-Control: max-age=0");


$output = fopen("php://output", "w");


fputcsv($output, [
    'N°', 
    'Nom', 
    'Prénom', 
    'Statut', 
    'Date d\'enregistrement'
], ';');


foreach ($presences as $index => $presence) {
    fputcsv($output, [
        $index + 1,
        htmlspecialchars($presence['nom']),
        htmlspecialchars($presence['prénom']),
        ucfirst($presence['statut']),
        date('d/m/Y H:i', strtotime($presence['date_scan'] ?? 'now'))
    ], ';');
}

fclose($output);
exit;