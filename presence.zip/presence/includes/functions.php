<?php
require_once 'config.php';


function createSeance($cours_id, $date_heure, $sujet) {
    global $db;
    
    $stmt = $db->prepare("INSERT INTO séances (cours_id, date_heure, sujet) VALUES (?, ?, ?)");
    return $stmt->execute([$cours_id, $date_heure, $sujet]);
}


function getSeanceById($seance_id) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT s.*, c.nom as cours_nom 
                            FROM séances s
                            JOIN cours c ON s.cours_id = c.id
                            WHERE s.id = ?");
        $stmt->execute([$seance_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Erreur getSeanceById: ".$e->getMessage());
        return false;
    }
}


function getSeances() {
    global $db;
    
    $stmt = $db->query("SELECT s.*, c.nom as cours_nom FROM séances s JOIN cours c ON s.cours_id = c.id");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}



function markPresence($etudiant_id, $seance_id) {
    global $db;
    
    try {
        $stmt = $db->prepare("INSERT INTO présences (étudiant_id, séance_id, statut) 
                             VALUES (:etudiant_id, :seance_id, 'présent')
                             ON DUPLICATE KEY UPDATE statut = 'présent'");
        return $stmt->execute([
            ':etudiant_id' => $etudiant_id,
            ':seance_id' => $seance_id
        ]);
    } catch (PDOException $e) {
        error_log("Erreur lors de l'enregistrement de la présence: " . $e->getMessage());
        return false;
    }
}

function getPresencesBySeance($seance_id) {
    global $db;
    
    $stmt = $db->prepare("SELECT p.*, u.nom, u.prénom FROM présences p JOIN utilisateurs u ON p.étudiant_id = u.id WHERE p.séance_id = ?");
    $stmt->execute([$seance_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


function generateQRCode($data, $size = 200) {
    require_once '../vendor/autoload.php'; 
    
    $qrCode = new Endroid\QrCode\QrCode($data);
    $qrCode->setSize($size);
    
    header('Content-Type: '.$qrCode->getContentType());
    echo $qrCode->writeString();
    exit;
}
?>