<?php
require_once 'config.php';


function login($email, $password) {
    global $db;
    
    $stmt = $db->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['mot_de_passe'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nom'] = $user['nom'];
        $_SESSION['prenom'] = $user['prénom'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['rôle'];
        
        return true;
    }
    
    return false;
}


function register($nom, $prenom, $email, $password, $role = 'étudiant') {
    global $db;

    $stmt = $db->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        return false;
    }
    

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $db->prepare("INSERT INTO utilisateurs (nom, prénom, email, mot_de_passe, rôle) VALUES (?, ?, ?, ?, ?)");
    $success = $stmt->execute([$nom, $prenom, $email, $hashedPassword, $role]);
    
    return $success;
}
?>