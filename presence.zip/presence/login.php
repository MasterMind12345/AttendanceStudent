<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


$error = $_SESSION['error'] ?? '';
$info = $_SESSION['info'] ?? '';
unset($_SESSION['error'], $_SESSION['info']);



if (isLoggedIn()) {
    handleQrPresence();
    redirectBasedOnRole();
    exit();
}


if (isset($_GET['qr_redirect'])) {
    $info = "Connectez-vous dans les 5 minutes pour valider votre présence";
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['error'] = "Erreur de sécurité. Veuillez réessayer.";
        header('Location: login.php');
        exit();
    }

    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Email et mot de passe requis";
    } elseif (authenticateUser($email, $password)) {
        handleQrPresence();
        redirectBasedOnRole();
        exit();
    } else {
        $error = "Identifiants incorrects";
    
        sleep(2);
    }
}


$_SESSION['csrf_token'] = bin2hex(random_bytes(32));



function authenticateUser($email, $password) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT id, nom, prénom, email, mot_de_passe, rôle 
                            FROM utilisateurs 
                            WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['mot_de_passe'])) {
            // Régénération ID session pour prévenir fixation
            session_regenerate_id(true);
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nom'] = $user['nom'];
            $_SESSION['prénom'] = $user['prénom'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['rôle'];
            $_SESSION['logged_in'] = true;
            $_SESSION['last_login'] = time();
            
            return true;
        }
    } catch (PDOException $e) {
        error_log("Login error for $email: " . $e->getMessage());
    }
    
    return false;
}

function handleQrPresence() {
    if (!isset($_SESSION['qr_seance']) || $_SESSION['role'] !== 'étudiant') {
        return;
    }

    $seance = $_SESSION['qr_seance'];
    

    if (time() - $seance['time'] > 300) {
        $_SESSION['error'] = "Délai expiré (5 minutes max après scan)";
        unset($_SESSION['qr_seance']);
        return;
    }

    if (markStudentPresence($_SESSION['user_id'], $seance['id'])) {
        $_SESSION['success'] = sprintf(
            "Présence enregistrée pour %s (%s)",
            htmlspecialchars($seance['seance_info']['cours_nom']),
            date('d/m/Y H:i', strtotime($seance['seance_info']['date_heure']))
        );
    } else {
        $_SESSION['error'] = "Erreur lors de l'enregistrement";
    }
    
    unset($_SESSION['qr_seance']);
}

function markStudentPresence($student_id, $seance_id) {
    global $db;
    
    try {
        $db->beginTransaction();
        
      
        $stmt = $db->prepare("SELECT 1 FROM inscriptions 
                            WHERE étudiant_id = ? 
                            AND cours_id = (
                                SELECT cours_id FROM séances WHERE id = ?
                            )");
        $stmt->execute([$student_id, $seance_id]);
        
        if (!$stmt->fetch()) {
            throw new Exception("Étudiant non inscrit à ce cours");
        }
        
        $stmt = $db->prepare("INSERT INTO présences 
                            (étudiant_id, séance_id, statut, date_scan)
                            VALUES (?, ?, 'présent', NOW())
                            ON DUPLICATE KEY UPDATE 
                            statut = VALUES(statut),
                            date_scan = NOW()");
        
        $success = $stmt->execute([$student_id, $seance_id]);
        $db->commit();
        
        return $success;
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Presence error: " . $e->getMessage());
        return false;
    }
}

function redirectBasedOnRole() {
    $role = $_SESSION['role'] ?? '';
    $locations = [
        'admin' => 'admin/dashboard.php',
        'enseignant' => 'teacher/dashboard.php',
        'étudiant' => 'user/dashboard.php'
    ];
    
    header('Location: ' . ($locations[$role] ?? 'index.php'));
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Gestion des Présences IUT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #1cc88a;
            --dark-color: #5a5c69;
        }
        
        .login-container {
            height: 100vh;
            background: linear-gradient(135deg, var(--primary-color) 0%, #2575fc 100%);
            display: flex;
            align-items: center;
        }
        
        .login-card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border: none;
            overflow: hidden;
        }
        
        .login-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            padding: 1.5rem;
            text-align: center;
        }
        
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            padding: 0.75rem 1rem;
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .form-control:focus {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border-color: rgba(255, 255, 255, 0.4);
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.1);
        }
        
        .btn-login {
            background-color: var(--secondary-color);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background-color: #17a673;
            transform: translateY(-2px);
        }
        
        .input-group-text {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: rgba(255, 255, 255, 0.7);
            min-width: 45px;
            justify-content: center;
        }
        
        .alert {
            border: none;
            backdrop-filter: blur(5px);
        }
        
        .footer-link {
            color: rgba(255, 255, 255, 0.7);
            transition: color 0.3s;
            text-decoration: none;
        }
        
        .footer-link:hover {
            color: white;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card login-card bg-dark bg-opacity-75 text-white">
                        <div class="login-header">
                            <img src="assets/img/logo-iut.png" alt="Logo IUT" height="50" class="mb-3">
                            <h3 class="mb-1"><i class="fas fa-user-shield me-2"></i>Connexion</h3>
                            <p class="mb-0 opacity-75">Système de gestion des présences</p>
                        </div>
                        
                        <div class="card-body p-4 p-md-5">
                            <?php if ($error): ?>
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($info): ?>
                                <div class="alert alert-info alert-dismissible fade show">
                                    <i class="fas fa-info-circle me-2"></i><?= htmlspecialchars($info) ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (isset($_SESSION['success'])): ?>
                                <div class="alert alert-success alert-dismissible fade show">
                                    <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($_SESSION['success']) ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <?php unset($_SESSION['success']); ?>
                            <?php endif; ?>
                            
                            <form method="POST" class="mt-4">
                                <div class="mb-4">
                                    <label for="email" class="form-label">Email institutionnel</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control" id="email" name="email" 
                                               placeholder="prenom.nom@etu.iut.fr" required
                                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <label for="password" class="form-label">Mot de passe</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" class="form-control" id="password" name="password" 
                                               placeholder="••••••••" required>
                                        <button class="btn btn-outline-secondary toggle-password" type="button">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="d-grid mb-4">
                                    <button type="submit" class="btn btn-login btn-lg">
                                        <i class="fas fa-sign-in-alt me-2"></i>Se connecter
                                    </button>
                                </div>
                                
                                <div class="d-flex justify-content-between mb-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="remember" name="remember">
                                        <label class="form-check-label" for="remember">Se souvenir de moi</label>
                                    </div>
                                    <a href="forgot_password.php" class="text-white-50 footer-link">
                                        <i class="fas fa-question-circle me-1"></i>Mot de passe oublié ?
                                    </a>
                                </div>
                            </form>
                            
                            <div class="text-center pt-3 border-top border-secondary">
                                <p class="mb-0 text-white-50">Première connexion ? 
                                    <a href="register.php" class="footer-link">
                                        <i class="fas fa-user-plus me-1"></i>Activer votre compte
                                    </a>
                                </p>
                            </div>
                        </div>
                        
                        <div class="card-footer text-center py-3 bg-dark bg-opacity-50">
                            <small class="text-white-50">
                                Système de présence IUT &copy; <?= date('Y') ?> - 
                                <a href="#" class="footer-link">Aide</a> | 
                                <a href="#" class="footer-link">Confidentialité</a>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>

        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const icon = this.querySelector('i');
                const passwordInput = this.closest('.input-group').querySelector('input');
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.classList.replace('fa-eye', 'fa-eye-slash');
                } else {
                    passwordInput.type = 'password';
                    icon.classList.replace('fa-eye-slash', 'fa-eye');
                }
            });
        });
        

        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.querySelector('.input-group-text').style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.querySelector('.input-group-text').style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
            });
        });
        
    
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
        
   
        document.getElementById('email')?.focus();
    </script>
</body>
</html>