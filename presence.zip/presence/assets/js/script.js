
document.addEventListener('DOMContentLoaded', function() {

  if (document.querySelector('.alert-success')) {
      setTimeout(() => {
          document.querySelector('.alert-success').style.display = 'none';
      }, 5000);
  }

  if (document.querySelector('.alert-danger')) {
      setTimeout(() => {
          document.querySelector('.alert-danger').style.display = 'none';
      }, 5000);
  }
  

  if (document.getElementById('qrScannerModal')) {
      const qrModal = document.getElementById('qrScannerModal');
      
      qrModal.addEventListener('hidden.bs.modal', function () {
          const resultsDiv = document.getElementById('qr-reader-results');
          if (resultsDiv) {
              resultsDiv.innerHTML = '';
          }
      });
  }
});


function exportToExcel(tableId, filename) {
  const table = document.getElementById(tableId);
  const html = table.outerHTML;
  

  const blob = new Blob([html], {type: 'application/vnd.ms-excel'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename || 'table.xls';
  a.click();
}