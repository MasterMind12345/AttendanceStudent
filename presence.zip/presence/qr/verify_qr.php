<?php
require_once '../includes/config.php';

require_once '../includes/functions.php';

if (!isset($_GET['data'])) {
    $_SESSION['error'] = "QR Code invalide - Aucune donnée reçue";
    redirect('../login.php');
}

$raw_data = urldecode($_GET['data']);
$data = explode(':', $raw_data);


if (count($data) !== 3 || $data[0] !== 'PRESENCE_IUT') {
    $_SESSION['error'] = "Format QR Code invalide";
    redirect('../login.php');
}

$seance_id = $data[1];
$signature = $data[2];


if ($signature !== md5($seance_id.SECRET_KEY)) {
    $_SESSION['error'] = "Signature QR Code invalide";
    redirect('../login.php');
}

$seance = getSeanceById($seance_id);
if (!$seance) {
    $_SESSION['error'] = "Séance introuvable";
    redirect('../login.php');
}


$_SESSION['qr_seance'] = [
    'id' => $seance_id,
    'time' => time(),
    'seance_info' => $seance
];


$_SESSION['info'] = "Veuillez vous connecter pour valider votre présence à la séance: ".
                   htmlspecialchars($seance['cours_nom'])." - ".
                   date('d/m/Y H:i', strtotime($seance['date_heure']));

redirect('../login.php?qr_redirect=1');