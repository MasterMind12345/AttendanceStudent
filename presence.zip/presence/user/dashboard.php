<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Récupérer les séances auxquelles l'étudiant est inscrit
$user_id = $_SESSION['user_id'];
$seances = [];
try {
    $stmt = $db->prepare("SELECT s.*, c.nom as cours_nom 
                         FROM séances s 
                         JOIN cours c ON s.cours_id = c.id
                         JOIN cours_etudiants ce ON c.id = ce.cours_id
                         WHERE ce.étudiant_id = ?
                         ORDER BY s.date_heure DESC");
    $stmt->execute([$user_id]);
    $seances = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Gérer l'erreur
}

// Récupérer les alertes pour l'étudiant
$alertes = [];
try {
    $stmt = $db->prepare("SELECT * FROM alertes WHERE étudiant_id = ? ORDER BY date DESC LIMIT 5");
    $stmt->execute([$user_id]);
    $alertes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Gérer l'erreur
}
?>

<div class="alert alert-success">
        <?= $_SESSION['success'] ?>
    </div>
    <?php unset($_SESSION['success']); ?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Étudiant - Gestion des présences</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Gestion des présences</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Tableau de bord</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-8">
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Mes séances</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($seances)): ?>
                            <div class="alert alert-info">Aucune séance programmée</div>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($seances as $seance): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h5 class="mb-1"><?= htmlspecialchars($seance['cours_nom']) ?></h5>
                                            <small><?= date('d/m/Y H:i', strtotime($seance['date_heure'])) ?></small>
                                        </div>
                                        <p class="mb-1"><?= htmlspecialchars($seance['sujet']) ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Mes alertes</h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($alertes)): ?>
                            <div class="alert alert-info">Aucune alerte</div>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($alertes as $alerte): ?>
                                    <div class="list-group-item list-group-item-<?= $alerte['type'] === 'avertissement' ? 'warning' : 'danger' ?>">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h6 class="mb-1"><?= ucfirst($alerte['type']) ?></h6>
                                            <small><?= date('d/m/Y H:i', strtotime($alerte['date'])) ?></small>
                                        </div>
                                        <p class="mb-1"><?= htmlspecialchars($alerte['message']) ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Scanner un QR Code</h4>
                    </div>
                    <div class="card-body text-center">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#qrScannerModal">
                            <i class="bi bi-qr-code-scan"></i> Scanner
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal pour le scanner QR -->
    <div class="modal fade" id="qrScannerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Scanner un QR Code</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <div id="qr-reader" style="width: 100%"></div>
                    <div id="qr-reader-results"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        function onScanSuccess(decodedText, decodedResult) {
            // Vérifier si le QR code est valide
            if (decodedText.startsWith('presence_iut:')) {
                // Rediriger vers la page de vérification
                window.location.href = '../qr/verify_qr.php?data=' + encodeURIComponent(decodedText);
            } else {
                document.getElementById('qr-reader-results').innerHTML = 
                    '<div class="alert alert-danger">QR Code invalide</div>';
            }
        }

        var html5QrcodeScanner = new Html5QrcodeScanner(
            "qr-reader", { fps: 10, qrbox: 250 });
            
        // Démarrer le scanner lorsque le modal est ouvert
        document.getElementById('qrScannerModal').addEventListener('shown.bs.modal', function () {
            html5QrcodeScanner.render(onScanSuccess);
        });
        
        // Arrêter le scanner lorsque le modal est fermé
        document.getElementById('qrScannerModal').addEventListener('hidden.bs.modal', function () {
            html5QrcodeScanner.clear();
        });
    </script>
</body>
</html>